
  # AI Image/Video Generator

  This is a code bundle for AI Image/Video Generator. The original project is available at https://www.figma.com/design/y5XOUdO9ndSA79mAi4jq01/AI-Image-Video-Generator.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  